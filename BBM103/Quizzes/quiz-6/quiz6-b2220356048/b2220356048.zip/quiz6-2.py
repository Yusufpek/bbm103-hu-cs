import sys

count = int(sys.argv[1])

# 1 3 5 7 9 = 2n -1
totalStar = 2 * count - 1
startsPyramidUp = [(i*"*") for i in range(1,totalStar +1,2)]
startsPyramidDown = [(i*"*") for i in range(totalStar -2, 0,-2)]
pyramid = startsPyramidUp + startsPyramidDown

for star in pyramid:
    blanket = (totalStar - (len(star))) // 2
    print(blanket * " " + star)