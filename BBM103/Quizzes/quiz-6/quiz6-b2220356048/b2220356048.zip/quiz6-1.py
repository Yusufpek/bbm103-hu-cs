import sys

count = int(sys.argv[1])

totalStarCount = 2 * count - 1

def writeStarUp(i):
    if(i == totalStarCount):
        return totalStarCount * "*"
    else:
        blanket = (totalStarCount - i) // 2
        return (blanket * " ")+ (i * "*" )+ "\n" + writeStarUp(i + 2)

def writeStarDown(i):
    blanket = (totalStarCount - i) // 2
    if(i <= 1):
        return (blanket * " ") + "*"
    else:
        return (blanket * " ")+ (i * "*" )+ "\n" + writeStarDown(i - 2)

print(writeStarUp(1));
print(writeStarDown(totalStarCount-2))